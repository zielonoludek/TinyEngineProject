#pragma once
#include "Enemy.h"
class Tank : public Enemy
{
public:
	Tank(Vector position);
};

